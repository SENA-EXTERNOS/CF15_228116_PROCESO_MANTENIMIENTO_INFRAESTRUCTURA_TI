function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5qJnB4gNAQF":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

